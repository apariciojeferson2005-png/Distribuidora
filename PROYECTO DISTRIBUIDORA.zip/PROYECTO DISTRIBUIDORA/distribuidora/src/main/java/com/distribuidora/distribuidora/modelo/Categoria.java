package com.distribuidora.distribuidora.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import java.util.List;

@Entity
@Table(name = "categorias")
@Data
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre de la categoría es obligatorio")
    @Column(nullable = false, length = 100)
    private String nombre;

    @NotBlank(message = "El slug es necesario para las URLs")
    @Column(unique = true, nullable = false)
    private String slug; // Ej: "anillos-de-plata"

    // Relación inversa: Una categoría tiene muchos productos
    @OneToMany(mappedBy = "categoria")
    private List<Producto> productos;
}