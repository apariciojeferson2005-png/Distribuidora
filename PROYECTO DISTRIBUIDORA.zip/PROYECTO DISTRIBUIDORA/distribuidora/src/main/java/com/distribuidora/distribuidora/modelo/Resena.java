package com.distribuidora.distribuidora.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "resenas")
@Data
public class Resena {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "producto_id")
    private Producto producto;

    @Min(1) @Max(5)
    private Integer calificacion; // Estrellas de 1 a 5

    @Column(columnDefinition = "TEXT")
    private String comentario;

    private LocalDateTime fecha;

    @PrePersist
    protected void onCreate() { fecha = LocalDateTime.now(); }
}