package com.distribuidora.distribuidora.controlador;

import com.distribuidora.distribuidora.modelo.ItemCarrito;
import com.distribuidora.distribuidora.modelo.Usuario;
import com.distribuidora.distribuidora.servicio.CarritoService;
import com.distribuidora.distribuidora.servicio.PedidoService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;

@Controller
@RequestMapping("/checkout")
public class CheckoutController {

    private final CarritoService carritoService;
    private final PedidoService pedidoService;

    public CheckoutController(CarritoService carritoService, PedidoService pedidoService) {
        this.carritoService = carritoService;
        this.pedidoService = pedidoService;
    }

    @GetMapping
    public String checkout(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        // Si NO está autenticado, muestra página de login/registro requerida
        if (auth == null || !auth.isAuthenticated() || auth.getPrincipal().equals("anonymousUser")) {
            model.addAttribute("requiresAuth", true);
            model.addAttribute("items", carritoService.obtenerItems());
            model.addAttribute("total", carritoService.calcularTotal());
            return "checkout-auth-required";
        }
        
        model.addAttribute("items", carritoService.obtenerItems());
        model.addAttribute("total", carritoService.calcularTotal());
        model.addAttribute("usuario", auth.getPrincipal());
        return "checkout";
    }

    @PostMapping("/procesar")
    public String procesarPedido(Authentication auth) {
        if (auth == null || !auth.isAuthenticated()) {
            return "redirect:/login";
        }
        
        Usuario usuario = (Usuario) auth.getPrincipal();
        List<ItemCarrito> items = carritoService.obtenerItems();

        if (items.isEmpty()) {
            return "redirect:/carrito";
        }

        // Guardamos el pedido en la Base de Datos
        pedidoService.crearPedido(usuario, items);
        
        carritoService.vaciarCarrito();
        return "redirect:/checkout/confirmacion";
    }

    @GetMapping("/confirmacion")
    public String confirmacion() {
        return "pedido-confirmado";
    }
}
