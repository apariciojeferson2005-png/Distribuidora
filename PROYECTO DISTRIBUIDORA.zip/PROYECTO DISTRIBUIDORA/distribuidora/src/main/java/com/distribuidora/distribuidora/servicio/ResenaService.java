package com.distribuidora.distribuidora.servicio;

import com.distribuidora.distribuidora.modelo.Resena;
import com.distribuidora.distribuidora.repositorio.ResenaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ResenaService {
    private final ResenaRepository resenaRepository;

    public ResenaService(ResenaRepository resenaRepository) {
        this.resenaRepository = resenaRepository;
    }

    public List<Resena> listarPorProducto(Long productoId) {
        return resenaRepository.findByProductoId(productoId);
    }

    public void guardar(Resena resena) { resenaRepository.save(resena); }
}