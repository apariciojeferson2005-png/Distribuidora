package com.distribuidora.distribuidora.modelo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;

@Entity
@Table(name = "productos")
@Data
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre del producto es obligatorio")
    private String nombre;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @NotNull(message = "El precio detal es obligatorio")
    @Positive
    private BigDecimal precioDetal;

    @NotNull(message = "El precio mayorista es obligatorio")
    @Positive
    private BigDecimal precioMayor;

    @NotNull(message = "Defina la cantidad mínima para aplicar precio mayorista")
    @Min(value = 2, message = "La cantidad mínima mayorista debe ser mayor a 1")
    private Integer cantidadMinimaMayorista;

    @Min(0)
    private Integer stock;

    private String material;
    private String imagenUrl;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id")
    @NotNull(message = "Debe seleccionar una categoría")
    private Categoria categoria;
}