package com.distribuidora.distribuidora.servicio;

import com.distribuidora.distribuidora.modelo.Categoria;
import com.distribuidora.distribuidora.repositorio.CategoriaRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    // Obtener todas las categorías (útil para el menú y formularios)
    public List<Categoria> listarTodas() {
        return categoriaRepository.findAll();
    }

    // Buscar una categoría específica por su ID
    public Categoria obtenerPorId(Long id) {
        return categoriaRepository.findById(id).orElse(null);
    }

    // Crear o actualizar una categoría
    public void guardar(Categoria categoria) {
        categoriaRepository.save(categoria);
    }

    // Eliminar categoría (solo si no tiene productos asociados)
    public void eliminar(Long id) {
        categoriaRepository.deleteById(id);
    }
}