package com.distribuidora.distribuidora.controlador;

import com.distribuidora.distribuidora.modelo.Pedido;
import com.distribuidora.distribuidora.modelo.Producto;
import com.distribuidora.distribuidora.servicio.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final ProductoService productoService;
    private final CategoriaService categoriaService;
    private final PedidoService pedidoService;

    // Constructor con Inyección de Dependencias Completa
    public AdminController(ProductoService productoService, CategoriaService categoriaService, PedidoService pedidoService) {
        this.productoService = productoService;
        this.categoriaService = categoriaService;
        this.pedidoService = pedidoService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        List<Producto> productos = productoService.listarTodos();

        // Cálculo de estadísticas para las tarjetas de resumen
        BigDecimal ventasTotales = pedidoService.obtenerVentasTotales();
        if (ventasTotales == null) ventasTotales = BigDecimal.ZERO;

        long stockCritico = productoService.contarProductosConStockCritico(10);

        model.addAttribute("totalVentas", ventasTotales);
        model.addAttribute("numPedidos", pedidoService.contarPedidos());
        model.addAttribute("alertasStock", stockCritico);
        model.addAttribute("productos", productos);
        
        return "admin/dashboard";
    }

    @GetMapping("/productos/editar/{id}")
    public String editarForm(@PathVariable Long id, Model model) {
        model.addAttribute("producto", productoService.obtenerPorId(id));
        model.addAttribute("categorias", categoriaService.listarTodas());
        return "admin/form-producto";
    }

    @GetMapping("/productos/eliminar/{id}")
    public String eliminarProducto(@PathVariable Long id) {
        productoService.eliminar(id);
        return "redirect:/admin/dashboard";
    }
}