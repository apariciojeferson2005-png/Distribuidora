package com.distribuidora.distribuidora.controlador;

import com.distribuidora.distribuidora.servicio.ProductoService;
import com.distribuidora.distribuidora.servicio.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TiendaController {

    private final ProductoService productoService;
    private final CategoriaService categoriaService;

    public TiendaController(ProductoService productoService, CategoriaService categoriaService) {
        this.productoService = productoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/novedades")
    public String novedades(Model model) {
        model.addAttribute("productos", productoService.obtenerNovedades());
        model.addAttribute("categorias", categoriaService.listarTodas());
        return "novedades";
    }

    @GetMapping("/buscar")
    public String buscar(@RequestParam(name = "q", required = false) String query, Model model) {
        if (query != null && !query.isBlank()) {
            model.addAttribute("productos", productoService.buscarPorNombre(query));
            model.addAttribute("query", query);
        } else {
            model.addAttribute("productos", productoService.listarTodos());
        }
        model.addAttribute("categorias", categoriaService.listarTodas());
        return "resultados-busqueda";
    }
}
