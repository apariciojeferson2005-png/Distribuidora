package com.distribuidora.distribuidora.controlador;

import com.distribuidora.distribuidora.modelo.Producto;
import com.distribuidora.distribuidora.servicio.ProductoService;
import com.distribuidora.distribuidora.servicio.ResenaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService productoService;
    private final ResenaService resenaService;

    public ProductoController(ProductoService productoService, ResenaService resenaService) {
        this.productoService = productoService;
        this.resenaService = resenaService;
    }

    // Listar todos los productos en la tienda
    @GetMapping
    public String listarProductos(Model model) {
        List<Producto> productos = productoService.listarTodos();
        model.addAttribute("productos", productos);
        model.addAttribute("titulo", "Nuestro Catálogo de Bisutería");
        return "productos/lista"; // Busca el archivo: src/main/resources/templates/productos/lista.html
    }

    // Ver el detalle de una joya específica
    @GetMapping("/{id}")
    public String verDetalle(@PathVariable Long id, Model model) {
        Producto producto = productoService.obtenerPorId(id);
        if (producto == null) {
            return "redirect:/productos"; // Si no existe, vuelve al catálogo
        }
        model.addAttribute("producto", producto);
        // Cargamos las reseñas para mostrarlas en la vista
        model.addAttribute("resenas", resenaService.listarPorProducto(id));
        return "productos/detalle";
    }
}