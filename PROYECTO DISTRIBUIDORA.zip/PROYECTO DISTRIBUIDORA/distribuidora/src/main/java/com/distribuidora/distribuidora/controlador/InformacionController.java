package com.distribuidora.distribuidora.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class InformacionController {

    @GetMapping("/blog")
    public String blog() {
        return "blog";
    }

    @GetMapping("/contacto")
    public String contacto() {
        return "contacto";
    }

    @GetMapping("/faq")
    public String faq() {
        return "faq";
    }

    @GetMapping("/acerca-de")
    public String acercaDe() {
        return "acerca-de";
    }
}
