package com.distribuidora.distribuidora.repositorio;

import com.distribuidora.distribuidora.modelo.Pedido;
import com.distribuidora.distribuidora.modelo.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    
    // Para ver el historial de compras de un cliente específico
    List<Pedido> findByUsuario(Usuario usuario);
    
    // Para que el admin pueda filtrar pedidos por su ID de usuario
    List<Pedido> findByUsuarioId(Long usuarioId);

    @Query("SELECT COALESCE(SUM(p.total), 0) FROM Pedido p")
    BigDecimal sumarTotalVentas();
}