package com.distribuidora.distribuidora.configuracion;

import com.distribuidora.distribuidora.modelo.Usuario;
import com.distribuidora.distribuidora.repositorio.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Si no hay usuarios, creamos el primer Administrador
        if (usuarioRepository.count() == 0) {
            Usuario admin = new Usuario();
            admin.setNombreCompleto("Administrador Principal");
            admin.setEmail("admin@distribuidora.com");
            // Encriptamos la clave "admin123"
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRol(com.distribuidora.distribuidora.modelo.Rol.ADMIN);
            admin.setTelefono("3001234567");
            
            usuarioRepository.save(admin);
            System.out.println(">>> Usuario ADMIN creado: admin@distribuidora.com / admin123");
        }
    }
}