package com.distribuidora.distribuidora.servicio;

import com.distribuidora.distribuidora.modelo.*;
import com.distribuidora.distribuidora.repositorio.PedidoRepository;
import com.distribuidora.distribuidora.repositorio.ProductoRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class PedidoService {
    private final PedidoRepository pedidoRepository;
    private final ProductoRepository productoRepository;

    public PedidoService(PedidoRepository pedidoRepository, ProductoRepository productoRepository) {
        this.pedidoRepository = pedidoRepository;
        this.productoRepository = productoRepository;
    }

    // Método para el resumen de ventas del Dashboard
    public List<Pedido> listarTodos() { return pedidoRepository.findAll(); }

    public long contarPedidos() { return pedidoRepository.count(); }

    public BigDecimal obtenerVentasTotales() {
        return pedidoRepository.sumarTotalVentas();
    }

    @Transactional
    public Pedido crearPedido(Usuario usuario, List<ItemCarrito> items) {
        Pedido pedido = new Pedido();
        pedido.setUsuario(usuario);
        pedido.setEstado(EstadoPedido.PENDIENTE);

        List<DetallePedido> detalles = new ArrayList<>();

        for (ItemCarrito item : items) {
            // 1. Buscamos el producto fresco de la BD para asegurar el stock real
            Producto producto = productoRepository.findById(item.getProducto().getId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

            // 2. Validamos y descontamos Stock
            if (producto.getStock() < item.getCantidad()) {
                throw new RuntimeException("Stock insuficiente para: " + producto.getNombre());
            }
            producto.setStock(producto.getStock() - item.getCantidad());
            productoRepository.save(producto);

            // 3. Creamos el detalle del pedido
            DetallePedido detalle = new DetallePedido();
            detalle.setProducto(producto);
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(item.getPrecioAplicado());
            detalle.setPedido(pedido); // Vinculamos el detalle al pedido padre
            detalles.add(detalle);
        }

        pedido.setDetalles(detalles);
        
        // Calcular total sumando los subtotales
        BigDecimal total = items.stream()
                .map(ItemCarrito::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        pedido.setTotal(total);

        // Al guardar el pedido, JPA guardará automáticamente los detalles gracias a CascadeType.ALL
        return pedidoRepository.save(pedido);
    }
}