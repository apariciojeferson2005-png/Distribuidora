package com.distribuidora.distribuidora.repositorio;

import com.distribuidora.distribuidora.modelo.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {
    // Buscar productos de una categoría específica
    List<Producto> findByCategoriaId(Long categoriaId);
    
    // Buscar productos que contengan una palabra (para el buscador)
    List<Producto> findByNombreContainingIgnoreCase(String nombre);

    // Contar productos con stock menor a cierta cantidad
    long countByStockLessThan(Integer stock);

    // Para filtros del catálogo (Punto 2 de tu idea)
    List<Producto> findByMaterial(String material);

    // Para la sección de "Novedades" (Punto 4 de tu idea) - Trae los últimos 8 agregados
    List<Producto> findTop8ByOrderByIdDesc();
}