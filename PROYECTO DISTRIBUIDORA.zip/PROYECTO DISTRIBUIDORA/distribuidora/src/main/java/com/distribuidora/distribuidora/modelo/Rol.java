package com.distribuidora.distribuidora.modelo;

public enum Rol {
    ADMIN,
    CLIENTE
}