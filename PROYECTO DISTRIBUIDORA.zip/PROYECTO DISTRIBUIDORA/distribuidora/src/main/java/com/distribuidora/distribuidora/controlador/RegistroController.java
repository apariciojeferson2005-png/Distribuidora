package com.distribuidora.distribuidora.controlador;

import com.distribuidora.distribuidora.modelo.Rol;
import com.distribuidora.distribuidora.modelo.Usuario;
import com.distribuidora.distribuidora.servicio.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegistroController {

    private final UsuarioService usuarioService;

    public RegistroController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/registro")
    public String formularioRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "registro";
    }

    @PostMapping("/registro")
    public String registrarUsuario(Usuario usuario) {
        if (usuario.getRol() == null) {
            usuario.setRol(Rol.CLIENTE);
        }
        usuarioService.registrarUsuario(usuario);
        return "redirect:/login?registro=success";
    }
}
