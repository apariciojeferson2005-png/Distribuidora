package com.distribuidora.distribuidora.servicio;

import com.distribuidora.distribuidora.modelo.ItemCarrito;
import com.distribuidora.distribuidora.modelo.Producto;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@SessionScope // Importante: Crea un carrito único por cada usuario conectado
public class CarritoService {
    private List<ItemCarrito> items = new ArrayList<>();

    public void agregarProducto(Producto producto, Integer cantidad) {
        // Validar que no se exceda el stock disponible
        int cantidadEnCarrito = items.stream()
                .filter(i -> i.getProducto().getId().equals(producto.getId()))
                .mapToInt(ItemCarrito::getCantidad)
                .findFirst()
                .orElse(0);

        int stockReal = producto.getStock() != null ? producto.getStock() : 0;
        if (cantidadEnCarrito + cantidad > stockReal) {
            throw new IllegalArgumentException("Stock insuficiente. Solo quedan " + stockReal + " unidades.");
        }

        Optional<ItemCarrito> itemExistente = items.stream()
                .filter(i -> i.getProducto().getId().equals(producto.getId()))
                .findFirst();

        if (itemExistente.isPresent()) {
            ItemCarrito item = itemExistente.get();
            
            int nuevaCantidad = item.getCantidad() + cantidad;
            
            // Recalcular precio basado en la NUEVA cantidad total
            BigDecimal nuevoPrecio = calcularPrecioUnitario(producto, nuevaCantidad);
            
            item.setPrecioAplicado(nuevoPrecio);
            item.setCantidad(nuevaCantidad);
            item.calcularSubtotal();
        } else {
            BigDecimal precioInicial = calcularPrecioUnitario(producto, cantidad);
            items.add(new ItemCarrito(producto, cantidad, precioInicial));
        }
    }

    // Lógica auxiliar para determinar el precio según volumen
    private BigDecimal calcularPrecioUnitario(Producto producto, Integer cantidad) {
        if (producto.getCantidadMinimaMayorista() != null && cantidad >= producto.getCantidadMinimaMayorista()) {
            return producto.getPrecioMayor();
        }
        return producto.getPrecioDetal();
    }

    public void eliminarProducto(Long productoId) {
        items.removeIf(i -> i.getProducto().getId().equals(productoId));
    }

    public List<ItemCarrito> obtenerItems() {
        return items;
    }

    public BigDecimal calcularTotal() {
        return items.stream()
                .map(ItemCarrito::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void vaciarCarrito() { items.clear(); }
}