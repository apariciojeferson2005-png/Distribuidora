package com.distribuidora.distribuidora.controlador;

import com.distribuidora.distribuidora.modelo.Producto;
import com.distribuidora.distribuidora.servicio.CarritoService;
import com.distribuidora.distribuidora.servicio.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/carrito")
public class CarritoController {

    private final CarritoService carritoService;
    private final ProductoService productoService;

    public CarritoController(CarritoService carritoService, ProductoService productoService) {
        this.carritoService = carritoService;
        this.productoService = productoService;
    }

    @GetMapping
    public String verCarrito(Model model) {
        model.addAttribute("items", carritoService.obtenerItems());
        model.addAttribute("total", carritoService.calcularTotal());
        return "carrito/ver"; // Necesitarás crear este HTML
    }

    @GetMapping("/agregar/{id}")
    public String agregarAlCarrito(@PathVariable Long id, @RequestParam(required = false, defaultValue = "1") Integer cantidad) {
        Producto producto = productoService.obtenerPorId(id);
        if (producto != null) {
            try {
                carritoService.agregarProducto(producto, cantidad);
            } catch (IllegalArgumentException e) {
                return "redirect:/carrito?error=stock";
            }
        }
        return "redirect:/carrito";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarDelCarrito(@PathVariable Long id) {
        carritoService.eliminarProducto(id);
        return "redirect:/carrito";
    }
}