package com.distribuidora.distribuidora.modelo;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class ItemCarrito {
    private Producto producto;
    private Integer cantidad;
    private BigDecimal precioAplicado; // Precio unitario efectivo (detal o mayorista)
    private BigDecimal subtotal;

    public ItemCarrito(Producto producto, Integer cantidad, BigDecimal precioAplicado) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioAplicado = precioAplicado;
        this.calcularSubtotal();
    }

    public void calcularSubtotal() {
        // Multiplicamos precio por cantidad
        this.subtotal = this.precioAplicado.multiply(new BigDecimal(this.cantidad));
    }
}