package com.distribuidora.distribuidora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DistribuidoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(DistribuidoraApplication.class, args);
	}

}
